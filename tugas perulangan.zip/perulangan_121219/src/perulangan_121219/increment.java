/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perulangan_121219;

/**
 *
 * @author 100001000
 */

public class increment {
 public static void main(String[] args) {
int i = 0;

while ( i <= 10 ){
    // blok kode yang akan diulang
    System.out.println("Perulangan ke-" + i);

    // increment nilai i
    i++;    
}}}
